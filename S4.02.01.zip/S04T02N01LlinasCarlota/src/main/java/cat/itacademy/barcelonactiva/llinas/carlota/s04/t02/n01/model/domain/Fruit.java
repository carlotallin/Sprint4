package cat.itacademy.barcelonactiva.llinas.carlota.s04.t02.n01.model.domain;

import jakarta.persistence.*;

@Entity 
@Table (name = "tableFruits")
public class Fruit {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	@Column(name="name")
	private String name;
	@Column(name="kilos")
	private int kilos;
	
	public Fruit() {
		
	}

	public Fruit(String name, int kilos) {
		this.name = name;
		this.kilos = kilos;
	}
	
	//GETTERS AND SETTERS
	public int getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public int getKilos() {
		return kilos;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setKilos(int kilos) {
		this.kilos = kilos;
	}
	
	//TO STRING
	
	@Override
	public String toString() {
		return "Fruit [id=" + id + ", name=" + name + ", kilos=" + kilos + "]";
	}
}