package cat.itacademy.barcelonactiva.llinas.carlota.s04.t02.n01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class S04T02N01LlinasCarlotaApplication {

	public static void main(String[] args) {
		SpringApplication.run(S04T02N01LlinasCarlotaApplication.class, args);
	}

}
