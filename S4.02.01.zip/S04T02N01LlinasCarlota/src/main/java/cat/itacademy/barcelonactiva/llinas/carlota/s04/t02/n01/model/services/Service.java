package cat.itacademy.barcelonactiva.llinas.carlota.s04.t02.n01.model.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import cat.itacademy.barcelonactiva.llinas.carlota.s04.t02.n01.model.domain.Fruit;
import cat.itacademy.barcelonactiva.llinas.carlota.s04.t02.n01.model.repository.FruitRepository;

public class Service implements ServiceInterface{

	@Autowired
	FruitRepository fruitRepo;
	
	//http://localhost:8080/fruita/add
	@PostMapping("/fruita/add")
	public ResponseEntity<String> addFruit(@RequestBody Fruit fruit) {
	
		try {
			fruitRepo.save(fruit);			
			return new ResponseEntity<>("\n*** Fruit added *** \n" + fruit.toString() , HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	//http://localhost:8080/fruita/update
	@PutMapping("/fruita/update/{id}")
	public ResponseEntity<String> updateFruit(Fruit fruitUpdated) {

		try {
			int id = (int) fruitUpdated.getId(); 
			Fruit repositoryFruit = (Fruit)fruitRepo.findById(id);

			if (repositoryFruit.getId() != id) {
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			} 
			else {
				//Fruit _fruitUpdated = new Fruit();
				repositoryFruit.setName(fruitUpdated.getName());
				repositoryFruit.setId(fruitUpdated.getId());
				repositoryFruit.setKilos(fruitUpdated.getKilos());
				return new ResponseEntity<>("\n*** Fruit updated *** \n" + repositoryFruit.toString(), HttpStatus.OK);
			} 
		} catch (Exception e) {
			return new ResponseEntity<>("\n*** There has been an error, try again! ***", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	//http://localhost:8080/fruita/delete/{id}
	@DeleteMapping("/fruita/delete/{id}")
	public ResponseEntity<String> deleteFruit(@PathVariable("id") int id) {		
		
		try {
			@SuppressWarnings("deprecation")
			Fruit searchedFruit = fruitRepo.getById(id);
			if (searchedFruit != null) {
				fruitRepo.delete(searchedFruit);
				return new ResponseEntity<String>("\n*** Fruit deleted *** \n" + searchedFruit.toString(), HttpStatus.OK);
			} 
			else {
				return new ResponseEntity<String>("\n*** This id doesn't exist, try again! ***", HttpStatus.NOT_FOUND);
			}
		} catch (Exception e) {
			return new ResponseEntity<>("\n*** There has been an error ***", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}		
		
	//http://localhost:8080/fruita/getOne/{id}
	@GetMapping("/fruita/getOne/{id}")
	public ResponseEntity<Fruit> getOneFruit(@PathVariable("id") int id) {
		
		try {
			Fruit foundFruit = (Fruit) fruitRepo.findById(id);
			if (foundFruit == null) {
				return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
			} 
			else {			
				return new ResponseEntity<>(foundFruit, HttpStatus.OK);
			}		
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	//http://localhost:8080/fruita/getAll
	@GetMapping("/fruita/getAll")
	public ResponseEntity<List<Fruit>> getAllFruit() {
		
		try {
			List<Fruit> list = fruitRepo.findAll();
			if (list.isEmpty()) {
				return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
			} 
			else {
				return new ResponseEntity<List<Fruit>>(list, HttpStatus.OK);
			}			
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}



}
