package cat.itacademy.barcelonactiva.llinas.carlota.s04.t02.n01.model.services;

import java.util.List;

import org.springframework.http.ResponseEntity;

import cat.itacademy.barcelonactiva.llinas.carlota.s04.t02.n01.model.domain.Fruit;

public interface ServiceInterface {
	
	public ResponseEntity<String> addFruit(Fruit fruita);
	
	public ResponseEntity<String> updateFruit(Fruit fruitaUpdate);
	
	public ResponseEntity<String> deleteFruit(int id);
	
	public ResponseEntity<Fruit> getOneFruit(int id);
	
	public ResponseEntity<List<Fruit>> getAllFruit();

}
