package cat.itacademy.barcelonactiva.llinas.carlota.s04.t02.n01.controller;

// LINKS USED: https://www.tutorialspoint.com/postman/postman_post_requests.htm
// https://www.bezkoder.com/spring-boot-jpa-h2-example/

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import cat.itacademy.barcelonactiva.llinas.carlota.s04.t02.n01.model.domain.Fruit;
import cat.itacademy.barcelonactiva.llinas.carlota.s04.t02.n01.model.repository.FruitRepository;

@CrossOrigin(origins = "http://localhost:8080")
@RestController
public class FruitController {

	@Autowired
	FruitRepository fruitRepository;
	
	//http://localhost:8080/fruita/add
	@PostMapping("/fruita/add")
	public ResponseEntity<Fruit> addFruit(@RequestBody Fruit fruit) {
	
		try {
			Fruit _fruit = fruitRepository.save(fruit);			
			return new ResponseEntity<>(_fruit, HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	//http://localhost:8080/fruita/update
	@PutMapping("/fruita/update/{id}")
	public ResponseEntity<Fruit> updateFruit(@PathVariable("id") int id,@RequestBody Fruit fruit) {
		
		try {
			List<Fruit> searchFruit = fruitRepository.findById(id);
			if (searchFruit == null) {
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			} 
			else {
				Fruit _fruit = searchFruit.get(0);
				_fruit.setName(fruit.getName());
				_fruit.setId(fruit.getId());
				_fruit.setKilos(fruit.getKilos());
				return new ResponseEntity<>(fruitRepository.save(_fruit), HttpStatus.OK);
			} 
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	//http://localhost:8080/fruita/delete/{id}
	@DeleteMapping("/fruita/delete/{id}")
	public ResponseEntity<String> deleteFruit(@PathVariable("id") int id) {		
		
		try {
			boolean searchFruit = fruitRepository.existsById(id);
			if (searchFruit) {
				fruitRepository.deleteById(id);
				return new ResponseEntity<String>("FRUIT DELETED", HttpStatus.OK);
			} 
			else {
				return new ResponseEntity<String>("THIS FRUIT DOESN'T EXIST", HttpStatus.NOT_FOUND);
			}
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}		
		
	//http://localhost:8080/fruita/getOne/{id}
	@GetMapping("/fruita/getOne/{id}")
	public ResponseEntity<Fruit> getFruitById(@PathVariable("id") int id) {
		
		try {
			List<Fruit> foundFruit = fruitRepository.findById(id);
			if (foundFruit== null) {
				return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
			} 
			else {			
				return new ResponseEntity<>(foundFruit.get(0), HttpStatus.OK);
			}		
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	//http://localhost:8080/fruita/getAll
	
	@GetMapping("/fruita/getAll")
	public ResponseEntity<List<Fruit>> getAll() {
		
		try {
			List<Fruit> list = fruitRepository.findAll();
			if (list.isEmpty()) {
				return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
			} 
			else {
				return new ResponseEntity<List<Fruit>>(list, HttpStatus.OK);
			}			
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
