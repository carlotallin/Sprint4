package cat.itacademy.barcelonactiva.llinas.carlota.s04.t02.n01.controller;

// LINKS USED: https://www.tutorialspoint.com/postman/postman_post_requests.htm
// https://www.bezkoder.com/spring-boot-jpa-h2-example/

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import cat.itacademy.barcelonactiva.llinas.carlota.s04.t02.n01.model.domain.Fruit;
import cat.itacademy.barcelonactiva.llinas.carlota.s04.t02.n01.model.services.ServiceInterface;

@CrossOrigin(origins = "http://localhost:8080")
@RestController
public class FruitController {

	@Autowired
	ServiceInterface fruitService;
	
	@PostMapping("/add")
	public ResponseEntity<String> addFruita(@RequestBody Fruit fruit) {	
		return fruitService.addFruit(fruit);
	}
	
	@PutMapping("/update")
	public ResponseEntity<String> updateFruita(@RequestBody Fruit fruit) {
		return fruitService.updateFruit(fruit);
		
	}
	
	@DeleteMapping("delete/{id}")
	public ResponseEntity<String> deleteFruita(@PathVariable int id) {
		return fruitService.deleteFruit(id);
	}
	
	@GetMapping("/getOne/{id}")
	public ResponseEntity<Fruit> getOneFruita(@PathVariable int id){
		return fruitService.getOneFruit(id);
	}
	
	@GetMapping("/getAll")
	public ResponseEntity<List<Fruit>> getAllFruita(){
		return  fruitService.getAllFruit();
	}
}
