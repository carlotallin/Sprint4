package cat.itacademy.barcelonactiva.llinas.carlota.s04.t02.n01.model.repository;

import org.springframework.stereotype.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import cat.itacademy.barcelonactiva.llinas.carlota.s04.t02.n01.model.domain.Fruit;

@Repository
public interface FruitRepository extends JpaRepository<Fruit, Integer>{
	  List<Fruit> findById(int id);
}